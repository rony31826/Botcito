import yts from 'yt-search';

let handler = async (m, { conn, usedPrefix, text, args, command }) => {
    if (!text) {
        conn.reply(m.chat, `Escriba su Búsqueda`, m, {
            contextInfo: {
                externalAdReply: {
                    mediaUrl: null,
                    mediaType: 1,
                    description: null,
                    title: mg,
                    body: wm,
                    previewType: 0,
                    thumbnail: img.getRandom(),
                    sourceUrl: redes.getRandom()
                }
            }
        });
        return;
    }
    
    try {
        let result = await yts(text);
        let ytres = result.videos;
        
        let listSections = [];
        for (let index in ytres) {
            let v = ytres[index];
            listSections.push({
                title: `--------------------------------------------`,
                rows: [
                    {
                        header: '🎶 AUDIO',
                        title: "",
                        description: `${v.title}\n${v.timestamp}`, 
                        id: `${usedPrefix}play.1 ${v.url}`
                    },
                    {
                        header: "🎥 VIDEO",
                        title: "" ,
                        description: `${v.title}\n${v.timestamp}`, 
                        id: `${usedPrefix}play.2 ${v.url}`
                    }
                ]
            });
        }

        await conn.sendList(m.chat, `Seleciona uno de tus resultados : ${text}`, `\n${wm}`, `Aqui`, listSections, m);
    } catch (err) {
        conn.reply(m.chat, 'Ocurrió un error durante la búsqueda. Por favor, intente de nuevo más tarde.', m);
        console.error(err);
    }
};

handler.help = ['playlist'];
handler.tags = ['dl'];
handler.command = /^playlist|ytbuscar|yts(earch)?$/i;
//handler.limit = 1
//handler.level = 3

export default handler;