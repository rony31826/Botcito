import axios from 'axios';

let handler = async (m, { conn, text, usedPrefix, command }) => {

    let fkontak = {

        "key": {

            "participants": "0@s.whatsapp.net",

            "remoteJid": "status@broadcast",

            "fromMe": false,

            "id": "Halo"

        },

        "message": {

            "contactMessage": {

                "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`

            }

        },

        "participant": "0@s.whatsapp.net"

    };

    if (!text) {

        return conn.reply(m.chat, `⚠️ *¿Qué TikTok quieres buscar? 🤔*\n\n⚡ *Ingresa un enlace de TikTok para descargar el video*\n*Ejemplo:* ${usedPrefix + command} https://vt.tiktok.com/ZSwWCk5o/`, fkontak, { contextInfo: { externalAdReply: { mediaUrl: null, mediaType: 1, description: null, title: mg, body: ' 💫 𝐒𝐮𝐩𝐞𝐫 𝐁𝐨𝐭 𝐃𝐞 𝐖𝐡𝐚𝐭𝐬𝐚𝐩𝐩 🥳 ', previewType: 0, thumbnail: img.getRandom(), sourceUrl: redes.getRandom() } } });

    }

    if (!/(?:https:?\/{2})?(?:w{3}\.)?tiktok\.com\/([^\s]+)/i.test(text)) {

        return conn.reply(m.chat, `*Enlace de TikTok incorrecto*`, fkontak, m);

    }

    const apiEndpoint = `https://api.lolhuman.xyz/api/tiktok?apikey=Ronny_Botcito&url=${encodeURIComponent(text)}`;

    const { key } = await conn.sendMessage(m.chat, { text: `⌛ 𝙀𝙨𝙥𝙚𝙧𝙚 ✋\n▰▰▰▱▱▱▱▱▱\n𝙔𝙖 𝙚𝙨𝙩𝙤𝙮 𝙙𝙚𝙨𝙘𝙖𝙧𝙜𝙖𝙙𝙤... 𝙨𝙪𝙨 𝙫𝙞𝙙𝙚𝙤 𝙙𝙚𝙡 𝙏𝙞𝙠𝙏𝙤𝙠 🔰` }, { quoted: fkontak });

    try {

        await delay(1000 * 2);

        await conn.sendMessage(m.chat, { text: `⌛ 𝙀𝙨𝙥𝙚𝙧𝙚 ✋ \n▰▰▰▰▰▱▱▱▱\n𝙔𝙖 𝙚𝙨𝙩𝙤𝙮 𝙙𝙚𝙨𝙘𝙖𝙧𝙜𝙖𝙙𝙤... 𝙨𝙪𝙨 𝙫𝙞𝙙𝙚𝙤 𝙙𝙚𝙡 𝙏𝙞𝙠𝙏𝙤𝙠 🔰`, edit: key });

        await delay(1000 * 2);

        await conn.sendMessage(m.chat, { text: `⌛ 𝙔𝙖 𝙘𝙖𝙨𝙞 🏃‍♂️💨\n▰▰▰▰▰▰▰▱▱`, edit: key });

        const response = await axios.get(apiEndpoint);

        const result = response.data.result;

        if (!result) {

            await conn.sendMessage(m.chat, { text: `No se pudo obtener la información del video de TikTok`, edit: key });

            return;

        }

        const { title, thumbnail, link } = result;

        await conn.sendFile(m.chat, link, 'tiktok.mp4', `*Aquí tienes 🔰*\n\n*${title}*`.trim(), m);

        await conn.sendMessage(m.chat, { text: `✅ 𝘾𝙤𝙢𝙥𝙡𝙚𝙩𝙖𝙙𝙤\n▰▰▰▰▰▰▰▰▰\n𝘼𝙦𝙪𝙞 𝙚𝙨𝙩𝙖 𝙩𝙪 𝙫𝙞𝙙𝙚𝙤 💫`, edit: key });

    } catch (error) {

        console.error('Error al obtener datos de la API:', error);

        await conn.sendMessage(m.chat, { text: `Ocurrió un error al procesar la solicitud`, edit: key });

    }

};

handler.help = ['tiktok'];

handler.tags = ['dl'];

handler.command = /^(tt|tiktok)(dl|nowm)?$/i;

export default handler;

const delay = time => new Promise(res => setTimeout(res, time));


