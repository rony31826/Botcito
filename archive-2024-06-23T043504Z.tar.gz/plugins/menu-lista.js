import { getDevice } from '@whiskeysockets/baileys'
import fs from 'fs'
import moment from 'moment-timezone'
import fetch from 'node-fetch'
import { xpRange } from '../lib/levelling.js'
const { levelling } = '../lib/levelling.js'
import PhoneNumber from 'awesome-phonenumber'
import { promises } from 'fs'
import { join } from 'path'
let handler = async (m, { conn, usedPrefix, usedPrefix: _p, __dirname, text, command }) => {
const dispositivo = await getDevice(m.key.id)
try {
let _package = JSON.parse(await promises.readFile(join(__dirname, '../package.json')).catch(_ => ({}))) || {}
let { exp, limit, level, role } = global.db.data.users[m.sender]
let { min, xp, max } = xpRange(level, global.multiplier)
let name = await conn.getName(m.sender)
let d = new Date(new Date + 3600000)
let locale = 'es'
let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
let week = d.toLocaleDateString(locale, { weekday: 'long' })
let date = d.toLocaleDateString(locale, {
day: 'numeric',
month: 'long',
year: 'numeric'
})
let dateIslamic = Intl.DateTimeFormat(locale + '-TN-u-ca-islamic', {
day: 'numeric',
month: 'long',
year: 'numeric'
}).format(d)
let time = d.toLocaleTimeString(locale, {
hour: 'numeric',
minute: 'numeric',
second: 'numeric'
})
let _uptime = process.uptime() * 1000
let _muptime
if (process.send) {
process.send('uptime')
_muptime = await new Promise(resolve => {
process.once('message', resolve)
setTimeout(resolve, 1000)
}) * 1000
}
let { money, joincount } = global.db.data.users[m.sender]
let user = global.db.data.users[m.sender]
let muptime = clockString(_muptime)
let uptime = clockString(_uptime)
let totalreg = Object.keys(global.db.data.users).length
let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length
let replace = {
'%': '%',
p: _p, uptime, muptime,
me: conn.getName(conn.user.jid),
npmname: _package.name,
npmdesc: _package.description,
version: _package.version,
exp: exp - min,
maxexp: xp,
totalexp: exp,
xp4levelup: max - exp,
github: _package.homepage ? _package.homepage.url || _package.homepage : '[unknown github url]',
level, limit, name, weton, week, date, dateIslamic, time, totalreg, rtotalreg, role,
readmore: readMore
}
text = text.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), (_, name) => '' + replace[name])
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let mentionedJid = [who]
let username = conn.getName(who)
let taguser = '@' + m.sender.split("@s.whatsapp.net")[0]
let pp = './Menu2.jpg'
let vn = 'https://qu.ax/bfaM.mp3'
let pareja = global.db.data.users[m.sender].pasangan 
const numberToEmoji = { "0": "0️⃣", "1": "1️⃣", "2": "2️⃣", "3": "3️⃣", "4": "4️⃣", "5": "5️⃣", "6": "6️⃣", "7": "7️⃣", "8": "8️⃣", "9": "9️⃣", }
let lvl = level
let emoji = Array.from(lvl.toString()).map((digit) => numberToEmoji[digit] || "❓").join("")

const lugarFecha = moment().tz('America/Lima')
const formatoFecha = {
weekdays: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
months: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
}
lugarFecha.locale('es', formatoFecha)
const horarioFecha = lugarFecha.format('dddd, DD [de] MMMM [del] YYYY || HH:mm A').replace(/^\w/, (c) => c.toUpperCase())

if (!/web|desktop|unknown/gi.test(dispositivo)) {  
let menu = `
*${horarioFecha}* \n
*Usuarios Registrados:* ${totalreg}
*Uptime:* ${uptime}

*Información del Usuario*
*Nombre:* ${name}
*Nivel:* ${level}
*Experiencia:* ${exp}
*Límite:* ${limit}`.trim()

/*
*Menú de Descargas y Categorías:*
1. *Descargas:* ${usedPrefix}descargasmenu
2. *Educación:* ${usedPrefix}educacionmenu
3. *Salud:* ${usedPrefix}saludmenu
4. *Noticias:* ${usedPrefix}noticiasmenu
5. *Clima:* ${usedPrefix}climamenu
6. *Transporte:* ${usedPrefix}transportemenu
7. *Economía:* ${usedPrefix}economiamenu
8. *Cultura y Ocio:* ${usedPrefix}culturamenu
9. *Compras:* ${usedPrefix}comprasmenu
10. *Productividad:* ${usedPrefix}productividadmenu

`.trim()
 */     
const buttonParamsJson = JSON.stringify({
title: "SERVICIOS",
description: "Infórmacion sobre este Bot",
sections: [
{ title: "ℹInformación", highlight_label: "Popular",
rows: [
{ header: "Informacion", title: "BOTCITO", description: "Infórmacion sobre este Bot", id: usedPrefix + "info" },

{ header: "Grupos/Canales", title: "informacion sobre los grupos", description: "¡Te esperamos!", id: usedPrefix + "grupos" },

{ header: "Donar", title: "si desea donar muchas gracias", description: "Gracias a las Donaciones nos mantenemos ala vanguardia y desarrolo del Bot", id: usedPrefix + "donar" }
]},

/*
{ title: "🔖 Atajos", highlight_label: "Popular",
rows: [
{ header: "🆕 Ser Bot (código)", title: "🔓 Para: Todos", description: "¡Conviértete en Bot con el método de código de 8 dígitos!", id: usedPrefix + "serbot --code" },
{ header: "🤖 Ser Bot (qr)", title: "🔓 Para: Todos", description: "Forma estándar de ser bot con código QR", id: usedPrefix + "serbot" },
{ header: "🚄 Velocidad", title: "🔓 Para: Todos", description: "Seleccione esto si desea saber el ping del Bot", id: usedPrefix + "ping" },
{ header: "😺 Estado", title: "🔓 Para: Todos", description: "Conoce en que estado se encuentra GataBot", id: usedPrefix + "estado" }
]},
*/

{ title: "Comandos del Bot", highlight_label: "Popular",
rows: [
{ header: "comandos principales del bot", title: "Servicos que ofrecemos iremos ampliando los servcicos", description: "Visita todos los comandos", id: usedPrefix + "allmenu" }
]}
]})


const interactiveMessage = {
body: { text: menu },
footer: { text:`Powered by Ronny` },
header: { title: `*BOTCITO AL SERVICIO*`, subtitle: "test4", hasMediaAttachment: false },
nativeFlowMessage: { buttons: [{ 
name: "single_select",
buttonParamsJson
}]
}}
const message = { messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 }, interactiveMessage }
await conn.relayMessage(m.chat, { viewOnceMessage: { message } }, {})
      
} else { 
let menu = `
*${horarioFecha}*\n
*Usuarios Registrados:* ${totalreg}


*Información del Usuario*
*Nombre:* ${name}
*Nivel:* ${level}
*Experiencia:* ${exp}
*Límite:* ${limit}

*Menú de Descargas y Categorías:*
1. *Descargas:* ${usedPrefix}descargasmenu
2. *Educación:* ${usedPrefix}educacionmenu
3. *Salud:* ${usedPrefix}saludmenu
4. *Noticias:* ${usedPrefix}noticiasmenu
5. *Clima:* ${usedPrefix}climamenu
6. *Transporte:* ${usedPrefix}transportemenu
7. *Economía:* ${usedPrefix}economiamenu
8. *Cultura y Ocio:* ${usedPrefix}culturamenu
9. *Compras:* ${usedPrefix}comprasmenu
10. *Productividad:* ${usedPrefix}productividadmenu
`.trim()

await conn.sendFile(m.chat, pp, 'lp.jpg', menu, m, false, { contextInfo: { forwardedNewsletterMessageInfo: { newsletterJid: '120363160031023229@newsletter', serverMessageId: '', newsletterName: 'INFINITY-WA 💫' }, mentionedJid, externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: wm, body: 'Ronny', previewType: 0, thumbnail: imagen3, sourceUrl: [md, yt, tiktok].getRandom()}}})
await conn.sendMessage(m.chat, { audio: { url: vn }, fileName: 'error.mp3', mimetype: 'audio/mp4', ptt: true }, { quoted: m }) 
}} catch (e) {
await m.reply('error')
//console.log('error')
console.log(e)}}

handler.command =/^(menu|menú|memu|memú|help\?)$/i
//handler.register = true
export default handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)
function clockString(ms) {
let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')}  