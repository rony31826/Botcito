import fetch from 'node-fetch';
import { getDevice } from '@whiskeysockets/baileys';
import ytdl from 'ytdl-core';
import axios from 'axios';
import fs from 'fs';
import path from 'path';

let data;
let buff;
let mimeType;
let fileName;
let apiUrl;
let apiUrl2;
let apiUrlsz;
let device;
let enviando = false;

const YOUTUBE_API_KEY = 'AIzaSyA6d3NohIvGsUhb8luG7qefvfXgfwpBMro';

const handler = async (m, { command, usedPrefix, conn, text }) => {
  device = await getDevice(m.key.id);

  if (!text) throw `Por favor, proporciona un texto válido. Uso: _${usedPrefix + command} <URL1,URL2,...>`;
  if (command === 'ytls' && (device == 'desktop' || device == 'web')) throw `*[❗] Los mensajes de botones aún no están disponibles en WhatsApp web. Accede a tu celular para poder ver y usar los mensajes con botones.*`;
  if (enviando) return;
  enviando = true;

  try {
    const urls = text.split(',').map(url => url.trim());
    for (const url of urls) {
      if (url.includes('playlist')) {
        await downloadPlaylist(url, conn, m);
      } else {
        await downloadAndSendAudio(url, conn, m);
      }
    }
    enviando = false;
  } catch (error) {
    console.log(error);
    enviando = false;
    throw `Error inesperado. Por favor, inténtalo de nuevo.`;
  }
};

handler.command = /^(ytpl)$/i;
export default handler;

const getPlaylistVideos = async (playlistId) => {
  let videos = [];
  let nextPageToken = '';
  do {
    const res = await axios.get('https://www.googleapis.com/youtube/v3/playlistItems', {
      params: {
        part: 'snippet',
        maxResults: 50,
        playlistId: playlistId,
        key: YOUTUBE_API_KEY,
        pageToken: nextPageToken,
      },
    });

    const items = res.data.items;
    videos.push(...items.map(item => item.snippet.resourceId.videoId));
    nextPageToken = res.data.nextPageToken;
  } while (nextPageToken);

  return videos;
};

const downloadVideo = async (videoId) => {
  const videoInfo = await ytdl.getInfo(videoId);
  const title = videoInfo.videoDetails.title;
  const filePath = path.resolve('./tmp', `${title}.mp3`);

  return new Promise((resolve, reject) => {
    ytdl(videoId, { filter: 'audioonly' })
      .pipe(fs.createWriteStream(filePath))
      .on('finish', () => resolve(filePath))
      .on('error', reject);
  });
};

const downloadPlaylist = async (playlistUrl, conn, m) => {
  try {
    const playlistId = getPlaylistId(playlistUrl);
    const videoIds = await getPlaylistVideos(playlistId);

    for (const videoId of videoIds) {
      try {
        const filePath = await downloadVideo(videoId);
        const buff = fs.readFileSync(filePath);
        await conn.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg', fileName: path.basename(filePath) }, { quoted: m });
        fs.unlinkSync(filePath);
      } catch (error) {
        console.error(`Error al descargar el video ${videoId}:`, error);
      }
    }

    console.log('Descarga de la lista de reproducción completa.');
  } catch (error) {
    console.error('Error al descargar la lista de reproducción:', error);
  }
};

const downloadAndSendAudio = async (url, conn, m) => {
  try {
    const videoInfo = await ytdl.getInfo(url);
    const title = videoInfo.videoDetails.title;
    const filePath = await downloadVideo(url);

    const buff = fs.readFileSync(filePath);
    await conn.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg', fileName: `${title}.mp3` }, { quoted: m });
    fs.unlinkSync(filePath);
  } catch (error) {
    console.error(`Error al descargar el audio de ${url}:`, error);
  }
};

const getPlaylistId = (url) => {
  const urlObj = new URL(url);
  return urlObj.searchParams.get('list');
};