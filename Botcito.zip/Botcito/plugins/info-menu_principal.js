const handler = async (m, { command, usedPrefix, conn, text }) => {

/*  device = await getDevice(m.key.id);
let handler  = async (m, { conn, usedPrefix: _p }) => { */
let info = `> *COMANDOS PRINCIPALES*

> ${usedPrefix}play = Busca una cancion y descarga ya sea audio o video.
> ${usedPrefix}ytl = Busca una playlist para descarga masiva de audio.
> ${usedPrefix}yts = Busca ya sea un audio o video de yotutube.
> ${usedPrefix}fb = Descarga un video de facebook.
> ${usedPrefix}tt = Descarga un video de tiktok.
> ${usedPrefix}apk = Descarga una aplicacion.

> Powered by ronny`.trim() 
conn.reply(m.chat, info, m, {
contextInfo: { externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, 
title: `${wm}`,
body: '', previewType: 0, thumbnail: imagen2, sourceUrl: nna}}})
}
handler.command = /^menuprincipal|allmenu$/i
export default handler
