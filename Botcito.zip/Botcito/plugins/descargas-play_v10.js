import axios from 'axios';
import ytdl from 'ytdl-core';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { prepareWAMessageMedia, generateWAMessageFromContent, getDevice } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Crear la carpeta ./tmp/ si no existe
const tmpDir = path.join(__dirname, '../tmp/');
if (!fs.existsSync(tmpDir)) {
  fs.mkdirSync(tmpDir);
}

const handler = async (m, { command, usedPrefix, conn, text, debug = false }) => {
  const YT_API_KEY = 'AIzaSyA6d3NohIvGsUhb8luG7qefvfXgfwpBMro';

  const getYoutubeInfo = async (url) => {
    try {
      const videoId = ytdl.getURLVideoID(url);
      const response = await axios.get(`https://www.googleapis.com/youtube/v3/videos?id=${videoId}&part=snippet,contentDetails&key=${YT_API_KEY}`);
      const videoInfo = response.data.items[0];
      return {
        title: videoInfo.snippet.title,
        image: videoInfo.snippet.thumbnails.high.url,
        url: url,
      };
    } catch (error) {
      throw new Error('Error al obtener información del video de YouTube.');
    }
  };

  const searchYoutube = async (query) => {
    try {
      const response = await axios.get('https://www.googleapis.com/youtube/v3/search', {
        params: {
          part: 'snippet',
          q: query,
          type: 'video',
          key: YT_API_KEY,
        },
      });
      const video = response.data.items[0];
      return {
        title: video.snippet.title,
        image: video.snippet.thumbnails.high.url,
        url: `https://www.youtube.com/watch?v=${video.id.videoId}`,
      };
    } catch (error) {
      throw new Error('Error al realizar la búsqueda en YouTube.');
    }
  };

  const downloadFile = async (url, format, quality) => {
    const videoId = ytdl.getURLVideoID(url);
    const filePath = path.resolve(tmpDir, `${videoId}.${format === 'audio' ? 'mp3' : 'mp4'}`);
    const writeStream = fs.createWriteStream(filePath);

    return new Promise((resolve, reject) => {
      const options = {
        filter: format === 'audio' ? 'audioonly' : 'videoandaudio',
        quality: quality === 'high' ? 'highest' : 'lowest',
      };

      ytdl(url, options)
        .pipe(writeStream)
        .on('finish', () => resolve(filePath))
        .on('error', reject);
    });
  };

  let device;
  try {
    device = await getDevice(m.key.id);
  } catch (err) {
    console.log('Error getting device:', err);
  }

  const sendDebugMessage = async (message) => {
    if (debug) {
      await conn.sendMessage(m.chat, { text: message }, { quoted: m });
    }
  };

  if (!text) {
    await sendDebugMessage(`Por favor, proporciona un texto válido. Uso: _${usedPrefix + command} despacito`);
    return;
  }

  if ((command === 'play' || command === 'playh') && (device == 'desktop' || device == 'web')) {
    await sendDebugMessage(`*[❗] Los mensajes de botones aún no están disponibles en WhatsApp web. Accede a tu celular para poder ver y usar los mensajes con botones.*`);
    return;
  }

  try {
    let data;
    await sendDebugMessage('Iniciando validación del enlace de YouTube...');
    if (await isValidYouTubeLink(text)) {
      await sendDebugMessage('Enlace de YouTube válido. Obteniendo información del video...');
      data = await getYoutubeInfo(text);
      await sendDebugMessage(`Información del video obtenida: ${data.title}`);
    } else {
      await sendDebugMessage('No se proporcionó un enlace de YouTube. Realizando búsqueda...');
      data = await searchYoutube(text);
      await sendDebugMessage(`Video encontrado: ${data.title}`);
    }

    const dataMessage = `*${data.title}*`.trim();
    if (!text.includes('@') && !['play', 'playh'].includes(command)) {
      await conn.sendMessage(m.chat, { text: dataMessage }, { quoted: m });
    }

    if (command === 'play' || command === 'playh') {
      await sendDebugMessage('Preparando mensaje interactivo...');
      const messa = await prepareWAMessageMedia({ image: { url: data.image } }, { upload: conn.waUploadToServer });
      const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: { text: dataMessage },
              footer: { text: `Powered by Ronny`.trim() },
              header: {
                hasMediaAttachment: true,
                imageMessage: messa.imageMessage,
              },
              nativeFlowMessage: {
                buttons: [
                  {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                      display_text: 'AUDIO',
                      id: `${usedPrefix}${command}.1 ${data.url} SN@`,
                    }),
                  },
                  {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                      display_text: 'VIDEO',
                      id: `${usedPrefix}${command}.2 ${data.url} SN@`,
                    }),
                  },
                ],
                messageParamsJson: '',
              },
            },
          },
        },
      }, { userJid: conn.user.jid, quoted: m });
      await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
      return;
    }

    if (command === 'play.1' || command === 'play.2' || command === 'playh.1' || command === 'playh.2') {
      let filePath;
      const quality = command.startsWith('play') ? 'high' : 'low';
      if (command.endsWith('.1')) {
        await sendDebugMessage(`Descargando archivo de audio en calidad ${quality}...`);
        filePath = await downloadFile(data.url, 'audio', quality);
        await sendDebugMessage('Archivo de audio descargado.');
      } else if (command.endsWith('.2')) {
        await sendDebugMessage(`Descargando archivo de video en calidad ${quality}...`);
        filePath = await downloadFile(data.url, 'video', quality);
        await sendDebugMessage('Archivo de video descargado.');
      }

      const fileData = fs.readFileSync(filePath);
      const mimeType = command.endsWith('.1') ? 'audio/mpeg' : 'video/mp4';
      await sendDebugMessage('Enviando archivo...');
      await conn.sendMessage(m.chat, { [mimeType.startsWith('audio') ? 'audio' : 'video']: fileData, mimetype: mimeType, fileName: path.basename(filePath) }, { quoted: m });
      fs.unlinkSync(filePath);
      await sendDebugMessage('Archivo enviado y eliminado del servidor.');
    }
  } catch (error) {
    console.log(error);
    await sendDebugMessage(`Error inesperado: ${error.message}`);
    throw `Error inesperado. Por favor, inténtalo de nuevo.`;
  }
};

handler.command = /^(play|play\.1|play\.2|playh|playh\.1|playh\.2)$/i;
export default handler;

async function isValidYouTubeLink(link) {
  const validPatterns = [
    /youtube\.com\/watch\?v=/i,
    /youtube\.com\/shorts\//i,
    /youtu\.be\//i,
    /youtube\.com\/embed\//i,
    /youtube\.com\/v\//i,
    /youtube\.com\/attribution_link\?a=/i,
    /yt\.be\//i,
    /googlevideo\.com\//i,
    /youtube\.com\.br\//i,
    /youtube-nocookie\.com\//i,
    /youtubeeducation\.com\//i,
    /m\.youtube\.com\//i,
    /youtubei\.googleapis\.com\//i,
  ];
  return validPatterns.some(pattern => pattern.test(link));
}