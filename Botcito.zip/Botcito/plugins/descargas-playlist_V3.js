import axios from 'axios';

let handler = async (m, { conn, usedPrefix, text, args, command }) => {
    if (!text) {
        conn.reply(m.chat, `Escriba su Búsqueda`, m, {
            contextInfo: {
                externalAdReply: {
                    mediaUrl: null,
                    mediaType: 1,
                    description: null,
                    title: mg,
                    body: wm,
                    previewType: 0,
                    thumbnail: img.getRandom(),
                    sourceUrl: redes.getRandom()
                }
            }
        });
        return;
    }
    
    try {
        // Define API key and endpoint
        const API_KEY = 'AIzaSyA6d3NohIvGsUhb8luG7qefvfXgfwpBMro';
        const URL = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=playlist&q=${encodeURIComponent(text)}&key=${API_KEY}`;

        // Fetch the playlists
        let response = await axios.get(URL);
        let result = response.data;
        let playlists = result.items;

        // Check if playlists is defined and has items
        if (!playlists || playlists.length === 0) {
            conn.reply(m.chat, 'No se encontraron playlists.', m);
            return;
        }

        // Prepare the sections for the response
        let listSections = [];
        for (let index in playlists) {
            let p = playlists[index].snippet;
            if (!p || !p.title) {
                continue; // Skip if snippet or title is undefined
            }
            listSections.push({
                title: `• Opción : [ ${index} ]`,
                rows: [
                    {
                        header: '📂 𝐏𝐋𝐀𝐘𝐋𝐈𝐒𝐓',
                        title: "",
                        description: `${p.title}\n${p.channelTitle}\n`, 
                        id: `${usedPrefix}ytpl https://www.youtube.com/playlist?list=${playlists[index].id.playlistId}`
                    }
                ]
            });
        }

        if (listSections.length === 0) {
            conn.reply(m.chat, 'No se encontraron playlists válidas.', m);
            return;
        }

        await conn.sendList(m.chat, `Selecciona uno de tus resultados: ${text}`, `\n${wm}`, `Aquí`, listSections, m);
    } catch (err) {
        conn.reply(m.chat, 'Ocurrió un error durante la búsqueda. Por favor, intente de nuevo más tarde.', m);
        console.error(err);
    }
};

handler.help = ['playlist'];
handler.tags = ['dl'];
handler.command = /^playlista|ytlista|yt(l)?$/i;
//handler.limit = 1
//handler.level = 3

export default handler;